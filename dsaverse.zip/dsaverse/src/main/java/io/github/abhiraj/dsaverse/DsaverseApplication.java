package io.github.abhiraj.dsaverse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsaverseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsaverseApplication.class, args);
	}

}
