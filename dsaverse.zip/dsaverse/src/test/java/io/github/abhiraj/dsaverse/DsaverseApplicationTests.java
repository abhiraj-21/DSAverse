package io.github.abhiraj.dsaverse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsaverseApplicationTests {

	@Test
	void contextLoads() {
	}

}
